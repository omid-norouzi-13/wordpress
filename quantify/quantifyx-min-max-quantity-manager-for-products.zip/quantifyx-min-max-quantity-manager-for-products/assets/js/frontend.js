jQuery(document).ready(function($) {

    var $form = $('form.variations_form');
    var $qtyInput = $('form.cart input.qty');
    var $warningBox = $('#custom-qty-warning');
    var $label = $('#dynamic-min-qty-label');
    var $dataNode = $('#qty-limits-data');

    var currentMin = parseFloat($dataNode.data('parent-min')) || 0;
    var currentMax = parseFloat($dataNode.data('parent-max')) || 0;

    function updateUI() {

        if (currentMin > 1) {
            $label.find('.qty-val').text(currentMin);
            $label.show();
        } else {
            $label.hide();
        }

        if (currentMin > 0) {
            $qtyInput.attr('min', currentMin);
            if (parseFloat($qtyInput.val()) < currentMin) {
                $qtyInput.val(currentMin);
            }
        }

        if (currentMax > 0) {
            $qtyInput.attr('max', currentMax);
        } else {
            $qtyInput.removeAttr('max');
        }
    }

    updateUI();

    $form.on('found_variation', function(event, variation) {

        var parentMin = parseFloat($dataNode.data('parent-min')) || 0;
        var parentMax = parseFloat($dataNode.data('parent-max')) || 0;

        currentMin = variation._min_qty ? parseFloat(variation._min_qty) : parentMin;
        currentMax = variation._max_qty ? parseFloat(variation._max_qty) : parentMax;

        updateUI();
        $warningBox.hide();
    });

    $form.on('reset_data', function() {
        currentMin = parseFloat($dataNode.data('parent-min')) || 0;
        currentMax = parseFloat($dataNode.data('parent-max')) || 0;

        updateUI();
        $warningBox.hide();
    });

    $('form.cart').on('submit', function(e) {

        var qty = parseFloat($qtyInput.val());
        var error = '';

        if (currentMin && qty < currentMin) error = 'حداقل سفارش بر اساس متر: ' + currentMin;
        if (currentMax && qty > currentMax) error = 'حداکثر سفارش بر اساس متر: ' + currentMax;

        if (error) {
            e.preventDefault();
            $warningBox.text(error).show();
        }
    });

    $qtyInput.on('input change', function() {
        $warningBox.hide();
    });

});