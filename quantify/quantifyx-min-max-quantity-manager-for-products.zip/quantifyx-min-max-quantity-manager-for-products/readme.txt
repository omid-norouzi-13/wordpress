=== QuantifyX – Min Max Quantity Manager for Products ===
Contributors: Infinite Innovate
Tags: woocommerce, quantity, min quantity, max quantity, cart validation, variation quantity
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

QuantifyX is a lightweight yet powerful WooCommerce plugin that allows store owners to define minimum and maximum purchase quantities for both simple products and product variations.

This plugin ensures customers cannot purchase below or above defined limits, improving inventory control, bulk selling strategies, and order consistency.

== Key Features ==

- Set minimum quantity per product
- Set maximum quantity per product
- Set min/max quantity per variation
- Automatic fallback from variation to parent product
- Real-time frontend validation using JavaScript
- Server-side validation for full security
- Dynamic UI updates on variation selection
- Displays minimum quantity on shop/archive pages
- No settings required – works directly in product editor
- Lightweight and optimized for performance
- Applied on Unlimited products no need to buy pro verison


== Use Cases ==

- Wholesale stores enforcing bulk orders
- Limited stock items with purchase caps
- B2B platforms with minimum order quantities
- Promotional campaigns with quantity restrictions

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate the plugin through the "Plugins" menu in WordPress
3. Make sure WooCommerce is installed and activated
4. Edit any product:
   - Go to Product Data → Inventory
   - Set Minimum and Maximum Quantity

== How It Works ==

1. Admin sets min/max quantity on product or variation level
2. On product page:
   - Quantity input updates dynamically
   - Minimum label is shown
3. On add-to-cart:
   - JavaScript prevents invalid submissions
4. On cart/checkout:
   - Server-side validation ensures rules are enforced

== Screenshots ==

1. Product edit page showing min/max fields
2. Variation settings with quantity limits
3. Product page showing minimum quantity label
4. Product page showing maximum quantity label
5. Shop page showing minimum quantity label
6. Cart validation error message

== Frequently Asked Questions ==

= Does it work with variable products? =
Yes, you can define min/max for each variation.

= What happens if variation has no limits? =
It automatically falls back to the parent product settings.

= Does it validate on checkout? =
Yes, validation is enforced both on frontend and server-side.

= Does it support all WooCommerce themes? =
Yes, it uses standard WooCommerce hooks.

= Is it compatible with page builders? =
Yes, it works with Elementor, WPBakery, and others.

== Technical Details ==

- Uses WooCommerce hooks and filters
- Data stored as post meta:
  - `_min_qty`
  - `_max_qty`
- JavaScript handles dynamic UI updates
- PHP enforces server-side validation

== Security ==

- Sanitized input using intval()
- Escaped output using esc_html() and esc_attr()
- No direct access allowed (ABSPATH checks)
- Server-side validation prevents bypass

== Performance ==

- No database overhead
- No external API calls
- Minimal JavaScript footprint
- Loads only on product pages

== Changelog ==

= 1.0.0 =
- Initial release
- Product-level min/max quantity support
- Variation-level min/max support
- Frontend validation system
- Cart validation enforcement
- Archive page minimum label display

== Upgrade Notice ==

= 1.0.0 =
Initial stable release

== Future Roadmap ==

- Global quantity rules
- Category-based quantity limits
- Bulk editing support
- REST API integration
- Analytics dashboard

== Support ==

For support or feature requests, please contact the developer.

== License ==

This plugin is licensed under the GPLv2 or later.

This means you are free to:
- Use
- Modify
- Distribute

== Credits ==

Developed by Infinite Innovate

== Tags ==

woocommerce quantity limit, min max quantity woocommerce, product quantity control, woocommerce validation plugin