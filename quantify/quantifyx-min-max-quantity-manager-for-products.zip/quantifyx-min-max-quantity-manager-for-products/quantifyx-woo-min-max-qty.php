<?php
/**
 * Plugin Name: QuantifyX – Min Max Quantity Manager for Products
 * Description: Add min/max quantity rules for products and variations to improve inventory control and optimize sales strategy.
 * Version: 1.0.0
 * Author: Infinite Innovate
 * License: GPL2+
 */

if (!defined('ABSPATH')) exit;

// Check WooCommerce dependency
function qx_init_plugin() {
    if (!class_exists('WooCommerce')) return;

    require_once plugin_dir_path(__FILE__) . 'includes/admin-fields.php';
    require_once plugin_dir_path(__FILE__) . 'includes/save-data.php';
    require_once plugin_dir_path(__FILE__) . 'includes/cart-validation.php';
    require_once plugin_dir_path(__FILE__) . 'includes/variation-data.php';
    require_once plugin_dir_path(__FILE__) . 'includes/frontend-ui.php';
    require_once plugin_dir_path(__FILE__) . 'includes/archive-display.php';

    add_action('wp_enqueue_scripts', function () {
        if (is_product()) {
            wp_enqueue_script(
                'qx-frontend',
                plugin_dir_url(__FILE__) . 'assets/js/frontend.js',
                ['jquery'],
                '1.0.0',
                true
            );
        }
    });
}
add_action('plugins_loaded', 'qx_init_plugin');