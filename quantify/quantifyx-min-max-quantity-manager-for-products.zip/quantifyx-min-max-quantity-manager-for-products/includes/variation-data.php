<?php
if (!defined('ABSPATH')) exit;

add_filter('woocommerce_available_variation', 'qx_add_variation_data');
function qx_add_variation_data($data) {

    $data['_min_qty'] = get_post_meta($data['variation_id'], '_min_qty', true);
    $data['_max_qty'] = get_post_meta($data['variation_id'], '_max_qty', true);

    return $data;
}