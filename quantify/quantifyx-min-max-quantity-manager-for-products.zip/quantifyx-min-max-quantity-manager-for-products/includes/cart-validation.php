<?php
if (!defined('ABSPATH')) exit;

add_action('woocommerce_check_cart_items', 'qx_validate_cart_qty');
function qx_validate_cart_qty() {

    foreach (WC()->cart->get_cart() as $cart_item) {

        $product_id = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
        $qty = $cart_item['quantity'];

        $min = get_post_meta($product_id, '_min_qty', true);
        $max = get_post_meta($product_id, '_max_qty', true);

        if (empty($min) && $cart_item['variation_id']) {
            $min = get_post_meta($cart_item['product_id'], '_min_qty', true);
        }

        if (empty($max) && $cart_item['variation_id']) {
            $max = get_post_meta($cart_item['product_id'], '_max_qty', true);
        }

        if ($min && $qty < $min) {
            wc_add_notice(sprintf(__('حداقل سفارش %d متر است برای محصول -> %s', 'woocommerce'), $min, $cart_item['data']->get_name()), 'error');
        }

        if ($max && $qty > $max) {
            wc_add_notice(sprintf(__('حداکثر سفارش %d متر است برای محصول -> %s', 'woocommerce'), $max, $cart_item['data']->get_name()), 'error');
        }
    }
}