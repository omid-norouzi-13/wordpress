<?php
if (!defined('ABSPATH')) exit;

add_action('woocommerce_before_add_to_cart_button', 'qx_frontend_ui');
function qx_frontend_ui() {

    global $product;

    $min = get_post_meta($product->get_id(), '_min_qty', true);
    $max = get_post_meta($product->get_id(), '_max_qty', true);

    echo '<div id="qty-limits-data" 
        data-parent-min="' . esc_attr($min) . '" 
        data-parent-max="' . esc_attr($max) . '"></div>';

    echo '<p id="dynamic-min-qty-label" style="display:none;">
        حداقل سفارش بر اساس متر: <strong class="qty-val"></strong>
    </p>';

    echo '<div id="custom-qty-warning" style="display:none;"></div>';
}