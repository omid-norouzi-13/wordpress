<?php
if (!defined('ABSPATH')) exit;

add_action('woocommerce_process_product_meta', 'qx_save_product_fields');
function qx_save_product_fields($post_id) {

    if (isset($_POST['_min_qty'])) {
        update_post_meta($post_id, '_min_qty', intval($_POST['_min_qty']));
    }

    if (isset($_POST['_max_qty'])) {
        update_post_meta($post_id, '_max_qty', intval($_POST['_max_qty']));
    }
}

add_action('woocommerce_save_product_variation', 'qx_save_variation_fields', 10, 2);
function qx_save_variation_fields($variation_id, $i) {

    if (isset($_POST['_min_qty'][$i])) {
        update_post_meta($variation_id, '_min_qty', intval($_POST['_min_qty'][$i]));
    }

    if (isset($_POST['_max_qty'][$i])) {
        update_post_meta($variation_id, '_max_qty', intval($_POST['_max_qty'][$i]));
    }
}