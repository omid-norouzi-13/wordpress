<?php
if (!defined('ABSPATH')) exit;

add_action('woocommerce_after_shop_loop_item_title', 'qx_archive_label', 15);
function qx_archive_label() {

    global $product;

    $min = get_post_meta($product->get_id(), '_min_qty', true);

    if (!empty($min)) {
        echo '<p> حداقل سفارش بر اساس متر: <strong>' . esc_html($min) . '</strong></p>';
    }
}