<?php
if (!defined('ABSPATH')) exit;

add_action('woocommerce_product_options_inventory_product_data', 'qx_add_product_fields');
function qx_add_product_fields() {
    echo '<div class="options_group">';

    woocommerce_wp_text_input([
        'id' => '_min_qty',
        'label' => __('Minimum Quantity', 'woocommerce'),
        'type' => 'number',
        'custom_attributes' => ['min' => '1'],
    ]);

    woocommerce_wp_text_input([
        'id' => '_max_qty',
        'label' => __('Maximum Quantity', 'woocommerce'),
        'type' => 'number',
        'custom_attributes' => ['min' => '1'],
    ]);

    echo '</div>';
}

add_action('woocommerce_variation_options_pricing', 'qx_add_variation_fields', 10, 3);
function qx_add_variation_fields($loop, $variation_data, $variation) {

    woocommerce_wp_text_input([
        'id' => "_min_qty[$loop]",
        'label' => __('Minimum Quantity | حداقل میزان سفارش برحسب متر', 'woocommerce'),
        'type' => 'number',
        'value' => get_post_meta($variation->ID, '_min_qty', true),
    ]);

    woocommerce_wp_text_input([
        'id' => "_max_qty[$loop]",
        'label' => __('Maximum Quantity | حداکثر میزان سفارش برحسب متر', 'woocommerce'),
        'type' => 'number',
        'value' => get_post_meta($variation->ID, '_max_qty', true),
    ]);
}