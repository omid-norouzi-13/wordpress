/* global wp, jQuery, optipixSettings */
( function ( $ ) {
	'use strict';

	var settings = window.optipixSettings || {};
	var i18n = settings.i18n || {};

	// وضعیت انتخاب فعلی کاربر (به‌صورت گلوبال تا بین رویدادهای مختلف آپلود در دسترس باشد)
	window.optipixChoice  = settings.defaultChoice || 'optimize';
	window.optipixSeoText = '';

	/**
	 * حدس زدن عنوان محصول/نوشته از فیلدهای رایج صفحه ویرایش
	 * (نوشته استاندارد وردپرس، ووکامرس و ...)
	 */
	function guessSeoText() {
		var selectors = [
			'#title',                                  // عنوان استاندارد نوشته/محصول در وردپرس
			'input[name="post_title"]',
			'.editor-post-title__input',                // ویرایشگر بلوکی (گوتنبرگ)
			'#woocommerce-product-data input[name="post_title"]'
		];

		for ( var i = 0; i < selectors.length; i++ ) {
			var $el = $( selectors[ i ] );
			if ( $el.length && $.trim( $el.val() || $el.text() ) !== '' ) {
				return $.trim( $el.val() || $el.text() );
			}
		}
		return '';
	}

	function buildPanelHtml() {
		var html = '';
		html += '<div class="optipix-panel">';
		html += '  <p class="optipix-panel-title">' + ( i18n.panelTitle || 'تنظیمات آپلود تصویر' ) + '</p>';
		html += '  <div class="optipix-choice-row">';
		html += '    <label class="optipix-radio-label">';
		html += '      <input type="radio" name="optipix-choice" value="original" /> ';
		html += '      ' + ( i18n.original || 'آپلود بدون تغییر' );
		html += '    </label>';
		html += '    <label class="optipix-radio-label">';
		html += '      <input type="radio" name="optipix-choice" value="optimize" /> ';
		html += '      ' + ( i18n.optimize || 'تبدیل به WebP و کاهش حجم' );
		html += '    </label>';
		html += '  </div>';

		if ( settings.autoSeoText ) {
			html += '  <div class="optipix-title-wrap">';
			html += '    <label for="optipix-seo-text">' + ( i18n.titleLabel || 'متن جایگزین (Alt)' ) + '</label>';
			html += '    <input type="text" id="optipix-seo-text" class="optipix-title-input" placeholder="' + ( i18n.titlePlaceholder || '' ) + '" />';
			html += '  </div>';
		}

		html += '</div>';
		return html;
	}

	/**
	 * تزریق پنل داخل مودال مدیا در صورتی که هنوز اضافه نشده باشد
	 */
	function injectPanel( $modal ) {
		if ( $modal.find( '.optipix-panel' ).length ) {
			return;
		}

		// ناحیه‌ای که فایل‌ها در آن رها/انتخاب می‌شوند (هم در تب "بارگذاری فایل‌ها" و هم بالای کل فریم)
		var $target = $modal.find( '.uploader-inline' ).first();
		if ( ! $target.length ) {
			$target = $modal.find( '.media-frame-content' ).first();
		}
		if ( ! $target.length ) {
			return;
		}

		var $panel = $( buildPanelHtml() );
		$target.prepend( $panel );

		// انتخاب پیش‌فرض
		$panel.find( 'input[name="optipix-choice"][value="' + window.optipixChoice + '"]' ).prop( 'checked', true );

		// پر کردن خودکار متن سئو
		var guessed = guessSeoText();
		window.optipixSeoText = guessed;
		$panel.find( '.optipix-title-input' ).val( guessed );

		// رویدادها
		$panel.on( 'change', 'input[name="optipix-choice"]', function () {
			window.optipixChoice = $( this ).val();
		} );

		$panel.on( 'input', '.optipix-title-input', function () {
			window.optipixSeoText = $.trim( $( this ).val() );
		} );
	}

	/**
	 * رصد باز شدن مودال مدیای وردپرس (در بخش‌های مختلف: تصویر شاخص، تصویر محصول،
	 * گالری محصول، افزودن تصویر به محتوا و ...) و تزریق پنل
	 */
	function watchForMediaModal() {
		var observer = new MutationObserver( function () {
			$( '.media-modal' ).each( function () {
				var $modal = $( this );
				if ( $modal.is( ':visible' ) ) {
					injectPanel( $modal );
				}
			} );
		} );

		observer.observe( document.body, { childList: true, subtree: true } );
	}

	/**
	 * افزودن پارامترهای انتخاب کاربر به هر فایلی که توسط پلاپلود (آپلودر وردپرس) ارسال می‌شود.
	 * این تکنیک با بازنویسی wp.Uploader.prototype.init پارامترهای دلخواه را
	 * به multipart_params هر آپلود اضافه می‌کند تا در سمت PHP قابل خواندن باشند.
	 */
	function hookUploaderParams() {
		if ( ! window.wp || ! wp.Uploader || ! wp.Uploader.prototype ) {
			return;
		}

		var originalInit = wp.Uploader.prototype.init;

		wp.Uploader.prototype.init = function () {
			var result = originalInit.apply( this, arguments );

			if ( this.uploader && typeof this.uploader.bind === 'function' ) {
				this.uploader.bind( 'BeforeUpload', function ( up ) {
					up.settings.multipart_params.optipix_choice   = window.optipixChoice || 'optimize';
					up.settings.multipart_params.optipix_seo_text = window.optipixSeoText || '';
				} );
			}

			return result;
		};
	}

	/**
	 * پوشش درگ‌ودراپ مستقیم در ویرایشگر بلوکی (گوتنبرگ) — مثل رها کردن تصویر روی
	 * باکس «تصویر شاخص» یا بلوک تصویر — که این موارد از مسیر REST API (/wp/v2/media)
	 * آپلود می‌شوند و از پلاپلود کلاسیک عبور نمی‌کنند. اینجا با یک میان‌افزار apiFetch
	 * پارامترهای انتخاب کاربر را به فرم‌دیتای همان درخواست اضافه می‌کنیم.
	 */
	function hookApiFetchParams() {
		if ( ! window.wp || ! wp.apiFetch || typeof wp.apiFetch.use !== 'function' ) {
			return;
		}

		wp.apiFetch.use( function ( options, next ) {
			var isMediaEndpoint =
				( options.path && options.path.indexOf( '/wp/v2/media' ) === 0 ) ||
				( options.url && options.url.indexOf( '/wp/v2/media' ) !== -1 );

			if ( isMediaEndpoint && options.body instanceof window.FormData ) {
				options.body.append( 'optipix_choice', window.optipixChoice || 'optimize' );
				options.body.append( 'optipix_seo_text', window.optipixSeoText || guessSeoText() );
			}

			return next( options );
		} );
	}

	$( function () {
		hookUploaderParams();
		hookApiFetchParams();
		watchForMediaModal();
	} );

} )( jQuery );
