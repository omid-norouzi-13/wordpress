<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * مدیریت تنظیمات و صفحه ادمین افزونه
 */
class OPTIPIX_Settings {

	private static $instance = null;

	const OPTION_KEY = 'optipix_settings';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'register_settings_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * مقادیر پیش‌فرض تنظیمات
	 */
	public static function get_default_settings() {
		return array(
			'always_ask'     => 1,          // نمایش انتخابگر برای هر آپلود
			'default_choice' => 'optimize', // 'optimize' یا 'original'
			'max_width'      => 1600,       // حداکثر عرض (پیکسل) - صفر = بدون محدودیت
			'max_height'     => 1600,       // حداکثر ارتفاع (پیکسل) - صفر = بدون محدودیت
			'quality'        => 80,         // کیفیت WebP (1 تا 100)
			'auto_seo_text'  => 1,          // پر کردن خودکار Alt/Title از عنوان محصول یا نوشته
			'delete_original' => 1,         // حذف فایل اصلی پس از تبدیل به WebP
		);
	}

	/**
	 * دریافت تنظیمات فعلی (با ادغام مقادیر پیش‌فرض)
	 */
	public static function get_settings() {
		$saved = get_option( self::OPTION_KEY, array() );
		return wp_parse_args( $saved, self::get_default_settings() );
	}

	public function register_settings_page() {
		add_options_page(
			__( 'بهینه‌ساز تصاویر آپلود', 'optipix' ),
			__( 'بهینه‌ساز تصاویر', 'optipix' ),
			'manage_options',
			'optipix-settings',
			array( $this, 'render_settings_page' )
		);
	}

	public function register_settings() {
		register_setting( 'optipix_settings_group', self::OPTION_KEY, array( $this, 'sanitize_settings' ) );
	}

	public function sanitize_settings( $input ) {
		$clean = array();
		$clean['always_ask']      = ! empty( $input['always_ask'] ) ? 1 : 0;
		$clean['default_choice']  = ( isset( $input['default_choice'] ) && 'original' === $input['default_choice'] ) ? 'original' : 'optimize';
		$clean['max_width']       = isset( $input['max_width'] ) ? max( 0, intval( $input['max_width'] ) ) : 0;
		$clean['max_height']      = isset( $input['max_height'] ) ? max( 0, intval( $input['max_height'] ) ) : 0;
		$clean['quality']         = isset( $input['quality'] ) ? min( 100, max( 1, intval( $input['quality'] ) ) ) : 80;
		$clean['auto_seo_text']   = ! empty( $input['auto_seo_text'] ) ? 1 : 0;
		$clean['delete_original'] = ! empty( $input['delete_original'] ) ? 1 : 0;
		return $clean;
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::get_settings();
		?>
		<div class="wrap" dir="rtl">
			<h1><?php esc_html_e( 'تنظیمات Optipix', 'optipix' ); ?></h1>
			<p class="description">
				<?php esc_html_e( 'فرمت‌های پشتیبانی‌شده برای تبدیل و بهینه‌سازی: JPEG، PNG، GIF، BMP، WebP، TIFF، HEIC و HEIF (روی آپلود با کلیک و آپلود با درگ‌ودراپ، به‌طور یکسان اعمال می‌شود).', 'optipix' ); ?>
				<br />
				<?php esc_html_e( 'توجه: پردازش فرمت‌های HEIC/HEIF نیازمند فعال بودن افزونه Imagick همراه با پشتیبانی libheif در سرور میزبان است؛ در صورت نبود این پشتیبانی، فایل HEIC/HEIF بدون تغییر و با همان فرمت اصلی آپلود خواهد شد.', 'optipix' ); ?>
			</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'optipix_settings_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'نمایش انتخابگر هنگام آپلود', 'optipix' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[always_ask]" value="1" <?php checked( $s['always_ask'], 1 ); ?> />
								<?php esc_html_e( 'هر بار که کاربر روی «افزودن تصویر» کلیک می‌کند، گزینه انتخاب نوع آپلود نمایش داده شود.', 'optipix' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'حالت پیش‌فرض', 'optipix' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION_KEY ); ?>[default_choice]">
								<option value="optimize" <?php selected( $s['default_choice'], 'optimize' ); ?>><?php esc_html_e( 'تبدیل به WebP و بهینه‌سازی', 'optipix' ); ?></option>
								<option value="original" <?php selected( $s['default_choice'], 'original' ); ?>><?php esc_html_e( 'آپلود بدون تغییر', 'optipix' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'حداکثر عرض (پیکسل)', 'optipix' ); ?></th>
						<td>
							<input type="number" min="0" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[max_width]" value="<?php echo esc_attr( $s['max_width'] ); ?>" class="small-text" />
							<p class="description"><?php esc_html_e( 'صفر یعنی بدون محدودیت عرض.', 'optipix' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'حداکثر ارتفاع (پیکسل)', 'optipix' ); ?></th>
						<td>
							<input type="number" min="0" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[max_height]" value="<?php echo esc_attr( $s['max_height'] ); ?>" class="small-text" />
							<p class="description"><?php esc_html_e( 'صفر یعنی بدون محدودیت ارتفاع.', 'optipix' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'کیفیت WebP', 'optipix' ); ?></th>
						<td>
							<input type="number" min="1" max="100" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[quality]" value="<?php echo esc_attr( $s['quality'] ); ?>" class="small-text" />
							<p class="description"><?php esc_html_e( 'عددی بین ۱ تا ۱۰۰ (پیشنهاد: ۷۵ تا ۸۵).', 'optipix' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'تولید خودکار متن جایگزین (Alt) برای سئو', 'optipix' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[auto_seo_text]" value="1" <?php checked( $s['auto_seo_text'], 1 ); ?> />
								<?php esc_html_e( 'عنوان تصویر، متن جایگزین (Alt) و نام فایل بر اساس عنوان محصول/نوشته یا متنی که کاربر وارد می‌کند تنظیم شود.', 'optipix' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'حذف فایل اصلی پس از تبدیل', 'optipix' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[delete_original]" value="1" <?php checked( $s['delete_original'], 1 ); ?> />
								<?php esc_html_e( 'پس از تبدیل به WebP، فایل اصلی (جهت صرفه‌جویی در فضا) حذف شود.', 'optipix' ); ?>
							</label>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
