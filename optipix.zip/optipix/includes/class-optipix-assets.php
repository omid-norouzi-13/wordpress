<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * بارگذاری فایل‌های جاوااسکریپت و CSS مورد نیاز در پنل مدیریت
 */
class OPTIPIX_Assets {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// این اکشن هر بار که wp_enqueue_media() فراخوانی شود اجرا می‌شود؛
		// یعنی دقیقاً در صفحاتی که مدیای وردپرس (تصویر شاخص، گالری محصول، تصویر محصول و ...) استفاده می‌شود.
		add_action( 'wp_enqueue_media', array( $this, 'enqueue_assets' ) );
	}

	public function enqueue_assets() {
		$settings = OPTIPIX_Settings::get_settings();

		wp_enqueue_style(
			'optipix-media-optimizer',
			OPTIPIX_PLUGIN_URL . 'assets/css/media-optimizer.css',
			array(),
			OPTIPIX_VERSION
		);

		wp_enqueue_script(
			'optipix-media-optimizer',
			OPTIPIX_PLUGIN_URL . 'assets/js/media-optimizer.js',
			array( 'jquery', 'media-editor', 'media-views' ),
			OPTIPIX_VERSION,
			true
		);

		wp_localize_script(
			'optipix-media-optimizer',
			'optipixSettings',
			array(
				'alwaysAsk'     => ! empty( $settings['always_ask'] ),
				'defaultChoice' => $settings['default_choice'],
				'autoSeoText'   => ! empty( $settings['auto_seo_text'] ),
				'i18n'          => array(
					'panelTitle'   => __( 'تنظیمات آپلود این تصویر', 'optipix' ),
					'original'     => __( 'آپلود بدون تغییر', 'optipix' ),
					'optimize'     => __( 'تبدیل به WebP و کاهش حجم', 'optipix' ),
					'titleLabel'   => __( 'متن جایگزین (Alt) / عنوان تصویر برای سئو', 'optipix' ),
					'titlePlaceholder' => __( 'مثال: نام محصول', 'optipix' ),
				),
			)
		);
	}
}
