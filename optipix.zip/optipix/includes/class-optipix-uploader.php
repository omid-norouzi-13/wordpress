<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پردازش سمت سرور فایل آپلود شده:
 * - تغییر نام فایل بر اساس متن سئو (قبل از ذخیره)
 * - تغییر سایز و تبدیل به WebP (بعد از ذخیره)
 * - تنظیم عنوان و Alt پیوست بر اساس متن سئو
 */
class OPTIPIX_Uploader {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * پسوند/مایم‌تایپ‌هایی که این افزونه علاوه بر فرمت‌های استاندارد وردپرس، اجازه آپلود و بهینه‌سازی آن‌ها را می‌دهد
	 */
	const EXTRA_MIME_TYPES = array(
		'heic'      => 'image/heic',
		'heif'      => 'image/heif',
		'tif|tiff'  => 'image/tiff',
	);

	private function __construct() {
		add_filter( 'upload_mimes', array( $this, 'allow_extra_mime_types' ) );
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'fix_filetype_detection' ), 10, 5 );
		add_filter( 'wp_handle_upload_prefilter', array( $this, 'maybe_rename_file' ) );
		add_filter( 'wp_handle_upload', array( $this, 'maybe_optimize_image' ) );
		add_action( 'add_attachment', array( $this, 'maybe_set_seo_meta' ) );
	}

	/**
	 * اطمینان از مجاز بودن آپلود فرمت‌های HEIC، HEIF و TIFF در وردپرس
	 *
	 * @param array $mimes
	 * @return array
	 */
	public function allow_extra_mime_types( $mimes ) {
		foreach ( self::EXTRA_MIME_TYPES as $ext => $mime ) {
			if ( empty( $mimes[ $ext ] ) ) {
				$mimes[ $ext ] = $mime;
			}
		}
		return $mimes;
	}

	/**
	 * برخی سرورها فایل‌های HEIC/HEIF را با finfo به‌درستی تشخیص نمی‌دهند و نوع فایل
	 * را نامعتبر اعلام می‌کنند؛ این متد بر اساس پسوند فایل یک تشخیص پشتیبان انجام می‌دهد.
	 */
	public function fix_filetype_detection( $data, $file, $filename, $mimes, $real_mime = '' ) {
		if ( ! empty( $data['ext'] ) && ! empty( $data['type'] ) ) {
			return $data;
		}

		$filetype = wp_check_filetype( $filename, self::EXTRA_MIME_TYPES );
		if ( $filetype['ext'] && $filetype['type'] ) {
			$data['ext']             = $filetype['ext'];
			$data['type']            = $filetype['type'];
			$data['proper_filename'] = $filename;
		}

		return $data;
	}

	/**
	 * بررسی اینکه آیا کاربر گزینه «بهینه‌سازی» را انتخاب کرده است
	 */
	private function is_optimize_requested() {
		if ( empty( $_POST['optipix_choice'] ) ) {
			return false;
		}
		return 'optimize' === sanitize_text_field( wp_unslash( $_POST['optipix_choice'] ) );
	}

	/**
	 * دریافت متن سئو ارسال شده از کاربر (عنوان محصول/نوشته)
	 */
	private function get_seo_text() {
		if ( empty( $_POST['optipix_seo_text'] ) ) {
			return '';
		}
		return sanitize_text_field( wp_unslash( $_POST['optipix_seo_text'] ) );
	}

	/**
	 * تغییر نام فایل قبل از آپلود بر اساس متن سئو (برای URL سئوپسند)
	 *
	 * @param array $file آرایه فایل ($_FILES ساختار)
	 * @return array
	 */
	public function maybe_rename_file( $file ) {
		$settings = OPTIPIX_Settings::get_settings();

		if ( empty( $settings['auto_seo_text'] ) ) {
			return $file;
		}
		if ( ! $this->is_optimize_requested() ) {
			return $file;
		}
		if ( empty( $file['type'] ) || strpos( $file['type'], 'image/' ) !== 0 ) {
			return $file;
		}

		$seo_text = $this->get_seo_text();
		if ( '' === $seo_text ) {
			return $file;
		}

		$slug = sanitize_title( $seo_text );
		if ( '' === $slug ) {
			return $file;
		}

		$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		if ( $ext ) {
			$file['name'] = $slug . '.' . $ext;
		}

		return $file;
	}

	/**
	 * پردازش تصویر بعد از انتقال فایل به آپلودها: تغییر سایز و تبدیل به WebP
	 *
	 * @param array $upload آرایه خروجی wp_handle_upload
	 * @return array
	 */
	public function maybe_optimize_image( $upload ) {
		if ( ! $this->is_optimize_requested() ) {
			return $upload;
		}
		if ( empty( $upload['file'] ) || empty( $upload['type'] ) || strpos( $upload['type'], 'image/' ) !== 0 ) {
			return $upload;
		}

		$allowed_types = array(
			'image/jpeg',
			'image/png',
			'image/gif',
			'image/bmp',
			'image/webp',
			'image/tiff',
			'image/heic',
			'image/heif',
		);
		if ( ! in_array( $upload['type'], $allowed_types, true ) ) {
			return $upload; // مثلا SVG دست‌نخورده باقی می‌ماند
		}

		$settings = OPTIPIX_Settings::get_settings();

		// توجه: پردازش HEIC/HEIF نیازمند Imagick با پشتیبانی از افزونه (delegate) libheif در سرور است.
		// در صورت نبود این پشتیبانی، wp_get_image_editor خطا برمی‌گرداند و فایل اصلی بدون تغییر آپلود می‌شود.
		$editor = wp_get_image_editor( $upload['file'] );
		if ( is_wp_error( $editor ) ) {
			return $upload;
		}

		// تغییر سایز در صورت نیاز
		$max_w = intval( $settings['max_width'] );
		$max_h = intval( $settings['max_height'] );
		if ( $max_w > 0 || $max_h > 0 ) {
			$size = $editor->get_size();
			if ( is_array( $size ) && ! empty( $size['width'] ) && ! empty( $size['height'] ) ) {
				$needs_resize = ( $max_w > 0 && $size['width'] > $max_w ) || ( $max_h > 0 && $size['height'] > $max_h );
				if ( $needs_resize ) {
					$editor->resize( $max_w > 0 ? $max_w : null, $max_h > 0 ? $max_h : null, false );
				}
			}
		}

		$editor->set_quality( intval( $settings['quality'] ) );

		$path_info = pathinfo( $upload['file'] );
		$new_file  = trailingslashit( $path_info['dirname'] ) . $path_info['filename'] . '.webp';

		// جلوگیری از رونویسی فایل با همین نام
		$new_file = $this->get_unique_filepath( $new_file );

		$saved = $editor->save( $new_file, 'image/webp' );

		if ( is_wp_error( $saved ) ) {
			return $upload; // در صورت خطا، فایل اصلی بدون تغییر آپلود می‌شود
		}

		// حذف فایل اصلی در صورت فعال بودن گزینه و اینکه فایل جدید متفاوت است
		if ( ! empty( $settings['delete_original'] ) && file_exists( $upload['file'] ) && $upload['file'] !== $saved['path'] ) {
			@unlink( $upload['file'] );
		}

		$upload['file'] = $saved['path'];
		$upload['type'] = ! empty( $saved['mime-type'] ) ? $saved['mime-type'] : 'image/webp';
		$upload['url']  = trailingslashit( dirname( $upload['url'] ) ) . basename( $saved['path'] );

		return $upload;
	}

	/**
	 * ساخت نام فایل یکتا برای جلوگیری از رونویسی
	 */
	private function get_unique_filepath( $path ) {
		$dir  = pathinfo( $path, PATHINFO_DIRNAME );
		$name = pathinfo( $path, PATHINFO_FILENAME );
		$ext  = pathinfo( $path, PATHINFO_EXTENSION );

		$counter  = 1;
		$new_path = $path;
		while ( file_exists( $new_path ) ) {
			$new_path = trailingslashit( $dir ) . $name . '-' . $counter . '.' . $ext;
			$counter++;
		}
		return $new_path;
	}

	/**
	 * تنظیم عنوان و متن جایگزین (Alt) پیوست بر اساس متن سئوی وارد شده
	 *
	 * @param int $attachment_id
	 */
	public function maybe_set_seo_meta( $attachment_id ) {
		$settings = OPTIPIX_Settings::get_settings();
		if ( empty( $settings['auto_seo_text'] ) ) {
			return;
		}

		$seo_text = $this->get_seo_text();
		if ( '' === $seo_text ) {
			return;
		}

		$mime = get_post_mime_type( $attachment_id );
		if ( ! $mime || strpos( $mime, 'image/' ) !== 0 ) {
			return;
		}

		wp_update_post(
			array(
				'ID'         => $attachment_id,
				'post_title' => $seo_text,
			)
		);

		update_post_meta( $attachment_id, '_wp_attachment_image_alt', $seo_text );
	}
}
