<?php
/**
 * Plugin Name: Optipix
 * Plugin URI:  https://academyshadman.com/optipix
 * Description: هنگام آپلود تصویر از هر بخش وردپرس (تصویر شاخص، تصویر محصول، گالری محصول و ...) یک انتخاب نمایش می‌دهد که آیا تصویر بدون تغییر آپلود شود یا به WebP تبدیل و سایزش کاهش یابد. از فرمت‌های HEIC، HEIF، PNG، JPEG و TIFF نیز پشتیبانی می‌کند و روی آپلود با درگ‌ودراپ نیز اعمال می‌شود. متن جایگزین (Alt) و عنوان تصویر نیز به‌صورت خودکار از عنوان محصول/نوشته پر می‌شود.
 * Version:     1.1.0
 * Author:      حامد شادمان
 * Author URI:  https://academyshadman.com
 * Text Domain: optipix
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // دسترسی مستقیم مجاز نیست
}

define( 'OPTIPIX_VERSION', '1.0.0' );
define( 'OPTIPIX_PLUGIN_FILE', __FILE__ );
define( 'OPTIPIX_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'OPTIPIX_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once OPTIPIX_PLUGIN_DIR . 'includes/class-optipix-settings.php';
require_once OPTIPIX_PLUGIN_DIR . 'includes/class-optipix-uploader.php';
require_once OPTIPIX_PLUGIN_DIR . 'includes/class-optipix-assets.php';

/**
 * راه‌اندازی افزونه
 */
function optipix_init_plugin() {
	OPTIPIX_Settings::instance();
	OPTIPIX_Uploader::instance();
	OPTIPIX_Assets::instance();
}
add_action( 'plugins_loaded', 'optipix_init_plugin' );

/**
 * مقادیر پیش‌فرض هنگام فعال‌سازی
 */
function optipix_activate_plugin() {
	$defaults = OPTIPIX_Settings::get_default_settings();
	if ( false === get_option( 'optipix_settings' ) ) {
		add_option( 'optipix_settings', $defaults );
	}
}
register_activation_hook( __FILE__, 'optipix_activate_plugin' );
